let DEVICE_NAME = "VJH00012FI"

// 54, 54, 54, 56, 54, 54
let Ble5Keys: (UInt8, UInt8, UInt8) = (44, 27, 44)
