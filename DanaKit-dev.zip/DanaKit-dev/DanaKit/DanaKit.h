//
//  DanaKit.h
//  DanaKit
//
//  Created by Randall Knutson on 9/11/21.
//  Copyright © 2021 LoopKit Authors. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DanaKit.
FOUNDATION_EXPORT double DanaKitVersionNumber;

//! Project version string for DanaKit.
FOUNDATION_EXPORT const unsigned char DanaKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DanaKit/PublicHeader.h>


