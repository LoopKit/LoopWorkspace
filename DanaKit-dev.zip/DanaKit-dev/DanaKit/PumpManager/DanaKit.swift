import Foundation
public class DanaKit {
    public static var disconnectReminderNotificationUUID = "f3e8b252-7515-40f5-9bba-a8b41a5c9650"

    init() {}
}
