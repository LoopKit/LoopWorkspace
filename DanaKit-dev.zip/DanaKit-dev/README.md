# DanaKit

Dana-I/Dana-RS Bluetooth PumpManager For Loop.

Library is based on JS port: https://github.com/bastiaanv/danars-js

## Status

This repository contains code being tested in Loop.

## For more information

Please join loop zulipchat at https://loop.zulipchat.com/
